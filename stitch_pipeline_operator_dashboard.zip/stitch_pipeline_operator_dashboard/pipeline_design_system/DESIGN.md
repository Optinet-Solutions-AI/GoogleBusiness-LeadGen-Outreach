---
name: Pipeline Design System
colors:
  surface: '#f9f9fd'
  surface-dim: '#d9dade'
  surface-bright: '#f9f9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f7'
  surface-container: '#ededf2'
  surface-container-high: '#e8e8ec'
  surface-container-highest: '#e2e2e6'
  on-surface: '#1a1c1f'
  on-surface-variant: '#42474f'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f0f0f4'
  outline: '#72777f'
  outline-variant: '#c2c7d0'
  surface-tint: '#35618d'
  primary: '#00375e'
  on-primary: '#ffffff'
  primary-container: '#1f4e79'
  on-primary-container: '#95bff1'
  inverse-primary: '#a0cafc'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#4c2e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a4300'
  on-tertiary-container: '#e9b268'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#a0cafc'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#184974'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffddb5'
  tertiary-fixed-dim: '#f5bc72'
  on-tertiary-fixed: '#2a1800'
  on-tertiary-fixed-variant: '#643f00'
  background: '#f9f9fd'
  on-background: '#1a1c1f'
  surface-variant: '#e2e2e6'
typography:
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: ui-monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  element-gap: 12px
  table-row-height: 40px
  sidebar-width: 240px
---

## Brand & Style
The design system is engineered for high-performance operators managing complex lead-generation workflows. The aesthetic follows a **High-Density Functionalist** approach, drawing inspiration from developer-centric tools like Linear and Vercel. 

The primary objective is utility and information density over visual flair. The UI prioritizes speed of recognition and execution, utilizing a strict "Flat Utility" style. By removing all decorative gradients, 3D effects, and unnecessary padding, the interface ensures that the data—not the container—is the focus. The emotional response is one of surgical precision, reliability, and professional-grade efficiency.

## Colors
The color palette is strictly light-mode, optimized for clarity in office environments. 

- **Primary Navy (#1F4E79):** Used for primary actions, active navigation states, and key brand identifiers.
- **Slate Neutrals:** A comprehensive scale of Slate-based grays handles the structural integrity of the UI. Backgrounds use the lightest tints (`#F8FAFC`), while text scales from Slate-900 for headings to Slate-500 for secondary metadata.
- **Semantic Logic:** Status colors are high-saturation but used sparingly. Success (Green), Warning (Amber), and Error (Rose) are reserved exclusively for data status indicators, validation, and system alerts to maintain a "quiet" interface until attention is required.

## Typography
This design system utilizes **Inter** for its neutral, systematic qualities. The typographic scale is intentionally compressed to support high-density data views.

- **Scale:** The base font size is 14px for standard body text. Secondary metadata and labels drop to 13px or 12px.
- **Hierarchy:** Contrast is achieved through weight (Medium 500/Semi-bold 600) and color (Slate-900 vs Slate-500) rather than large size differentials.
- **Mono Usage:** Use system-ui monospaced fonts for lead IDs, phone numbers, and timestamps to ensure character alignment in tabular data.

## Layout & Spacing
The layout employs a **Fluid-Fixed Hybrid** model. The main navigation and sidebars are fixed-width, while the central data workbench expands to utilize all available screen real estate.

- **Grid:** A 4px baseline grid governs all spacing. 
- **Density:** Gutters and margins are minimized (12px to 16px) to maximize the "above-the-fold" data visibility. 
- **Tables:** Tables are the primary view. They should utilize a `divide-y` approach with 1px Slate-200 borders, removing vertical grid lines to reduce visual noise.

## Elevation & Depth
This design system rejects traditional shadows and 3D depth in favor of **Tonal Layering** and **Structural Outlines**.

- **Borders:** Depth is communicated through 1px solid strokes (`Slate-200`).
- **Surface Levels:** 
  - Level 0: Global background (`#F8FAFC`).
  - Level 1: Primary workspace cards and sidebars (`#FFFFFF`).
  - Level 2: Hover states and active selections (`#F1F5F9`).
- **Shadows:** Only a single, extremely subtle "Drop Shadow" (2px blur, 4% opacity) is permitted for floating menus or modals to distinguish them from the workspace.

## Shapes
The shape language is a mix of geometric discipline and functional softness.

- **Cards & Containers:** Follow a `rounded-lg` (8px) standard for a modern, contained look.
- **Interactive Elements:** Buttons, Chips, and Tags utilize a **Full Radius (Pill)** shape. This creates a clear visual distinction between "static containers" (square-ish) and "actionable elements" (rounded).
- **Inputs:** Text fields use the same 8px radius as cards to maintain structural alignment.

## Components

### Buttons & Chips
- **Primary Button:** Navy (#1F4E79) background, white text, pill-shaped. No gradients.
- **Secondary/Ghost Button:** Transparent background, Slate-600 text, pill-shaped. On hover, a light Slate-100 background appears.
- **Status Chips:** Full-radius, light background tint (10% opacity of semantic color) with high-contrast text.

### Inputs & Fields
- **Standard Input:** 1px Slate-300 border, 8px radius, 14px Inter text. 
- **Focus State:** 1px Primary Navy border with a subtle 2px Primary Navy outer ring at 20% opacity.

### Tables (The Core Component)
- **Header:** Sticky headers, Slate-50 background, uppercase 12px labels.
- **Rows:** 40px height, `divide-y` Slate-200 separators. 
- **Cells:** Use monospaced font for numerical data. Lead status indicators should be left-aligned chips.

### Navigation
- **Sidebar:** Vertical, fixed at 240px. Uses 13px Inter Medium. Active states are indicated by a Primary Navy vertical bar (2px) on the left edge and a subtle Slate-100 background.

### Cards
- **Lead Card:** White background, 8px radius, 1px Slate-200 border. No shadow. Internal padding should be a tight 16px.